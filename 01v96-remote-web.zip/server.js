const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const os = require('os');
const fs = require('fs');
const path = require('path');
const SysTray = require('systray2').default;

const midiEngine = require('./src/midi-engine');
const protocol = require('./src/protocol');
const stateManager = require('./src/state-manager');
const dummy = require('./src/meter_dummy');
const masterMeter = require('./src/master-meter');
let dummyMeterInterval = null;

let meterDataBuffer = new Array(33).fill(0);
let lastMeterTime = 0;

const handleMIDIData = (midiData, rawMessage = null) => {
    if (!midiData) return;
    lastActivityTime = Date.now(); 

    // Processamento Independente do Master Meter
    if (rawMessage) {
        const mLevel = masterMeter.parse(rawMessage);
        if (mLevel !== null) {
            meterDataBuffer[32] = mLevel;
        }
    }

    // O METER_DATA processa canais 1-32. O 33 (Master) vem isolado.
    if (midiData.type === 'METER_DATA') {
        for (let i = 0; i < 32; i++) {
            if (midiData.levels[i] !== undefined) {
                meterDataBuffer[i] = midiData.levels[i];
            }
        }
    }

    // Emissão Throttled para a Web (apenas se sincronizado para evitar lag no boot)
    const now = Date.now();
    if (isFullySynced && (now - lastMeterTime > 50)) { 
        io.emit('meterData', meterDataBuffer);
        lastMeterTime = now;
    }
    
    if (midiData.type === 'METER_DATA') return;


    if (midiData.type === 'HEARTBEAT') return; 

    if (midiData.type === 'kChannelInput/kChannelIn') {
        const hex = midiData.raw ? Buffer.from(midiData.raw).toString('hex').toUpperCase() : 'N/A';
        console.log(`🎯 [PATCH CHANGE] Canal ${midiData.channel + 1}: Patch = ${midiData.value} ${midiData.value === 0 ? `(DEBUG HEX: ${hex})` : ''}`);
    }

    // Repassa o objeto INTEIRO para o gerenciador de estado (incluindo letras de nomes)
    stateManager.updateState(midiData);
    io.emit('update', midiData);
}

function iniciarDummy() {
    console.log("🛠️ [MODO DEMO] Ativando simulação automática de SysEx...");
    if (dummyMeterInterval) clearInterval(dummyMeterInterval);
    dummyMeterInterval = dummy.startMeterSimulation((sysex) => {
        // Log para conferência técnica
        if (Math.random() < 0.01) {
            const hex = Buffer.from(sysex).toString('hex').toUpperCase();
            console.log(`📥 [DUMMY MIDI] SysEx: ${hex.substring(0, 32)}...`);
        }
        
        const parsed = protocol.parseIncoming(sysex);
        if (parsed) handleMIDIData(parsed);
    });
}

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Variáveis Globais de Estado
let isConnected = false;
let systrayInstance = null;
let isTrayReady = false;
let buscaInterval = null; 
let linhaBuscaAtiva = false; 
let lastActivityTime = 0; // Timestamp da última mensagem recebida da mesa
let isSyncing = false; // Flag para evitar múltiplas sincronias simultâneas
let isFullySynced = false; // Flag para liberar os meters apenas após carga total
let hasSyncedNamesThisSession = false; // Flag para garantir que o server busque na mesa pelo menos 1 vez por boot

// Fila para pedidos de Dynamics, evitando encavalamento de MIDI
let dynamicsQueue = [];

process.title = "01V96-BRIDGE-SERVER";

app.use(express.static('public'));

// ===============================================
// API DE MODS / MACROS (VERSÃO MULTI-PRESET)
// ===============================================

// Endpoint de Reconhecimento de Hosts
app.get('/api/macros/hosts', (req, res) => {
    const hostsPath = path.join(__dirname, 'public/modules/macros', 'hosts.json');
    if (fs.existsSync(hostsPath)) {
        res.json(JSON.parse(fs.readFileSync(hostsPath, 'utf8')));
    } else {
        // Exemplo default se não existir
        res.json([
            { match: "192.168.15.99", preset: "pcmaria" },
            { match: "pcfavela", preset: "pcfavela" }
        ]);
    }
});

// Listar arquivos físicos (.js)
app.get('/api/macros', (req, res) => {
    const macrosDir = path.join(__dirname, 'public/modules/macros');
    if (!fs.existsSync(macrosDir)) fs.mkdirSync(macrosDir, { recursive: true });
    fs.readdir(macrosDir, (err, files) => {
        if (err) return res.status(500).json({ error: "Erro ao listar mods" });
        const jsFiles = files.filter(f => f.endsWith('.js') && !f.includes('.server.js')).map(f => f.replace('.js', ''));
        res.json(jsFiles);
    });
});

// 1. Manifesto Global de Slots (Chaves por Preset: { "default": {...}, "pcmaria": {...} })
app.get('/api/macros/slots', (req, res) => {
    const slotsPath = path.join(__dirname, 'public/modules/macros', 'slots.json');
    if (fs.existsSync(slotsPath)) {
        res.json(JSON.parse(fs.readFileSync(slotsPath, 'utf8')));
    } else { res.json({ "default": {} }); }
});

app.post('/api/macros/slots', express.json(), (req, res) => {
    const preset = req.query.preset || 'default';
    const slotsPath = path.join(__dirname, 'public/modules/macros', 'slots.json');
    
    let allSlots = {};
    if (fs.existsSync(slotsPath)) {
        try { allSlots = JSON.parse(fs.readFileSync(slotsPath, 'utf8')); } catch(e) {}
    }
    
    // Atualiza apenas a "caixa" (preset) correspondente
    allSlots[preset] = req.body;

    try {
        fs.writeFileSync(slotsPath, JSON.stringify(allSlots, null, 2));
        res.json({ success: true, preset });
    } catch (e) { res.status(500).json({ error: "Erro ao salvar manifesto centralizado" }); }
});

app.post('/api/macros/swap', express.json(), (req, res) => {
    const preset = req.query.preset || 'default';
    const fromIndex = parseInt(req.body.from);
    const toIndex = parseInt(req.body.to);
    if (isNaN(fromIndex) || isNaN(toIndex)) return res.status(400).json({ error: "Invalid indices" });

    const dirPath = path.join(__dirname, 'public/modules/macros');
    
    // 1. Swap in slots.json
    const slotsPath = path.join(dirPath, 'slots.json');
    if (fs.existsSync(slotsPath)) {
        try {
            let allSlots = JSON.parse(fs.readFileSync(slotsPath, 'utf8'));
            if (allSlots[preset]) {
                const tempFrom = allSlots[preset][fromIndex];
                const tempTo = allSlots[preset][toIndex];
                delete allSlots[preset][fromIndex];
                delete allSlots[preset][toIndex];
                if (tempTo) allSlots[preset][fromIndex] = tempTo;
                if (tempFrom) allSlots[preset][toIndex] = tempFrom;
                fs.writeFileSync(slotsPath, JSON.stringify(allSlots, null, 2));
            }
        } catch(e) {}
    }

    // 2. Swap configs in all plugin files
    if (fs.existsSync(dirPath)) {
        const files = fs.readdirSync(dirPath);
        for (let file of files) {
            if (file.endsWith('.json') && file !== 'slots.json' && file !== 'hosts.json') {
                const isTargetFile = (preset === 'default') ? !file.includes('_') : file.endsWith(`_${preset}.json`);
                if (isTargetFile) {
                    try {
                        const fp = path.join(dirPath, file);
                        let modConfig = JSON.parse(fs.readFileSync(fp, 'utf8'));
                        const keyFrom = `slot_${fromIndex}`;
                        const keyTo = `slot_${toIndex}`;
                        const tempFromData = modConfig[keyFrom];
                        const tempToData = modConfig[keyTo];
                        delete modConfig[keyFrom];
                        delete modConfig[keyTo];
                        if (tempToData) modConfig[keyFrom] = tempToData;
                        if (tempFromData) modConfig[keyTo] = tempFromData;
                        fs.writeFileSync(fp, JSON.stringify(modConfig, null, 2));
                    } catch(e) {}
                }
            }
        }
    }
    res.json({ success: true });
});

app.delete('/api/macros/slots', (req, res) => {
    const preset = req.query.preset;
    if (!preset || preset === 'default') return res.status(400).json({ error: "Preset inválido ou protegido" });

    const slotsPath = path.join(__dirname, 'public/modules/macros', 'slots.json');
    if (!fs.existsSync(slotsPath)) return res.status(404).json({ error: "Arquivo não encontrado" });

    try {
        let allSlots = JSON.parse(fs.readFileSync(slotsPath, 'utf8'));
        if (allSlots[preset]) {
            delete allSlots[preset];
            fs.writeFileSync(slotsPath, JSON.stringify(allSlots, null, 2));
            res.json({ success: true, deleted: preset });
        } else {
            res.status(404).json({ error: "Preset não existe no manifesto" });
        }
    } catch (e) { res.status(500).json({ error: "Erro ao deletar preset" }); }
});

// 2. Banco de Configuração do Mod por Preset
app.get('/api/macros/config/:modId', (req, res) => {
    const preset = req.query.preset || 'default';
    const modId = req.params.modId;
    const filename = preset === 'default' ? `${modId}.json` : `${modId}_${preset}.json`;
    const configPath = path.join(__dirname, 'public/modules/macros', filename);
    if (fs.existsSync(configPath)) {
        res.json(JSON.parse(fs.readFileSync(configPath, 'utf8')));
    } else { res.json({}); }
});

app.post('/api/macros/config/:modId', express.json(), (req, res) => {
    const preset = req.query.preset || 'default';
    const modId = req.params.modId;
    const filename = preset === 'default' ? `${modId}.json` : `${modId}_${preset}.json`;
    const configPath = path.join(__dirname, 'public/modules/macros', filename);
    try {
        fs.writeFileSync(configPath, JSON.stringify(req.body, null, 2));
        res.json({ success: true, mod: modId, preset });
    } catch (e) { res.status(500).json({ error: "Erro ao salvar config do mod" }); }
});

// Endpoint de Nomes para os Mods
app.get('/api/names', (req, res) => {
    if (fs.existsSync(namesFile)) {
        res.json(JSON.parse(fs.readFileSync(namesFile, 'utf8')));
    } else { res.json({}); }
});

app.get('/api/proxy', (req, res) => {
    const targetUrl = req.query.url;
    if (!targetUrl) return res.status(400).json({error: "Falta url param"});
    const reqProxy = http.get(targetUrl, (resProxy) => {
        let body = '';
        resProxy.on('data', chunk => body += chunk);
        resProxy.on('end', () => {
            try { res.json(JSON.parse(body)); } catch(e) { res.send(body); }
        });
    });
    reqProxy.on('error', err => res.status(500).json({ error: err.message }));
});

const configFile = path.join(__dirname, 'config.json');
const namesFile = path.join(__dirname, 'names.json');


// --- LÓGICA DA SYSTEM TRAY ---

function gerarConfigMenu() {
    return {
        menu: {
            icon: path.join(__dirname, 'public/favicon.ico'),
            title: "01V96 Control",
            tooltip: isConnected ? "Conectado à 01V96" : "Aguardando Conexão",
            items: [
                {
                    title: isConnected ? "🔄 Reconectar à Mesa" : "🔌 Conectar à Mesa",
                    enabled: true
                },
                {
                    title: "🌐 Abrir no Navegador",
                    enabled: true
                },
                { title: "---", enabled: false },
                {
                    title: "❌ Sair e Encerrar",
                    enabled: true
                }
            ]
        },
        debug: false,
        copyDir: true
    };
}

try {
    systrayInstance = new SysTray(gerarConfigMenu());

    systrayInstance.ready(() => {
        console.log("✅ Ícone da bandeja carregado.");
        isTrayReady = true;
    });

    systrayInstance.onClick((action) => {
        const tituloClicado = action.item.title;

        if (tituloClicado.includes("Conectar") || tituloClicado.includes("Reconectar")) {
            console.log("\n▶️ Comando Recebido: Tentar Conexão MIDI");
            iniciarBuscaAutomatica();
        } 
        else if (tituloClicado.includes("Abrir no Navegador")) {
            console.log("\n▶️ Comando Recebido: Abrindo Navegador");
            const url = `http://${os.hostname()}.local:4000`; 
            require('child_process').exec(`start ${url}`);
        } 
        else if (tituloClicado.includes("Sair e Encerrar")) {
            console.log("\n▶️ Comando Recebido: Encerrando o Servidor");
            if (midiEngine.close) midiEngine.close();
            process.exit(0);
        }
    });

} catch (e) {
    console.error("Erro ao instanciar Systray:", e);
}

function atualizarMenuTray() {
    if (systrayInstance && isTrayReady && systrayInstance._process) {
        systrayInstance.sendAction({
            type: 'update-menu',
            menu: gerarConfigMenu().menu
        });
    }
}


// --- FUNÇÕES DE APOIO E BUSCA ---

function loadConfig() {
    let config = { inIdx: null, outIdx: null, "loopmidi-monitor": false };
    if (fs.existsSync(configFile)) {
        try { 
            const loaded = JSON.parse(fs.readFileSync(configFile, 'utf8'));
            config = { ...config, ...loaded };
            // Atualiza config do Master Meter
            masterMeter.setConfig(config);
        } catch (err) {}
    }
    return config;
}

function saveConfig(configData) {
    try { fs.writeFileSync(configFile, JSON.stringify(configData, null, 2)); } catch (err) {}
}

function loadNames() {
    if (fs.existsSync(namesFile)) {
        try {
            const names = JSON.parse(fs.readFileSync(namesFile, 'utf8'));
            for (let i = 0; i < 32; i++) {
                if (names[i] !== undefined) {
                    stateManager.setChannelName(parseInt(i), names[i]);
                }
            }
            console.log("✅ [NAMES] Nomes carregados do arquivo names.json");
            return true;
        } catch (err) {
            console.error("❌ [NAMES] Erro ao carregar names.json:", err);
        }
    }
    return false;
}

function saveNames() {
    const s = stateManager.getState();
    const names = {};
    for (let i = 0; i < 32; i++) {
        names[i] = s.channels[i].name;
    }
    try {
        fs.writeFileSync(namesFile, JSON.stringify(names, null, 2));
        console.log("💾 [NAMES] Nomes salvos com sucesso em names.json");
    } catch (err) {
        console.error("❌ [NAMES] Erro ao salvar nomes:", err);
    }
}

function iniciarBuscaAutomatica() {
    if (buscaInterval) clearInterval(buscaInterval);

    atualizarMenuTray();

    console.log(""); 

    buscaInterval = setInterval(() => {
        if (isConnected) {
            clearInterval(buscaInterval);
            if (linhaBuscaAtiva) {
                process.stdout.write("\n"); 
                linhaBuscaAtiva = false;
            }
            return;
        }

        const horaAtual = new Date().toLocaleTimeString('pt-BR');
        const config = loadConfig();
        const searchMonitor = config["loopmidi-monitor"];

        const msg = searchMonitor ? '🔍 Buscando portas com "monitor" no nome...' : '🔍 Buscando Yamaha 01V96 na porta USB...';
        process.stdout.write(`\r[${horaAtual}] ${msg} \x1b[K`);
        linhaBuscaAtiva = true;

        const portas = midiEngine.getAvailablePorts();
        const inputs = portas.inputs || portas; 
        const outputs = portas.outputs || portas;

        let foundInIdx = -1;
        let foundOutIdx = -1;

        const matchesCriteria = (port) => {
            const name = port.name || port;
            if (!name) return false;
            const lower = String(name).toLowerCase();
            if (searchMonitor) {
                return lower.includes('monitor');
            }
            // Critério específico para Yamaha física: deve ter 'yamaha' e terminar com '-1' (ou conter '-1')
            return lower.includes('yamaha') && lower.includes('-1');
        };

        for (let i = 0; i < inputs.length; i++) {
            if (matchesCriteria(inputs[i])) { foundInIdx = i; break; }
        }

        for (let i = 0; i < outputs.length; i++) {
            if (matchesCriteria(outputs[i])) { foundOutIdx = i; break; }
        }

        if (foundInIdx !== -1 && foundOutIdx !== -1) {
            process.stdout.write("\n"); 
            linhaBuscaAtiva = false;
            
            const targetName = searchMonitor ? "loopMIDI (Monitor)" : "Yamaha 01V96";
            console.log(`[${horaAtual}] 🎯 ${targetName} encontrada! (In: ${foundInIdx}, Out: ${foundOutIdx}). Conectando...`);
            
            clearInterval(buscaInterval); 
            // Atualizamos o config mantendo o flag de monitor
            config.inIdx = foundInIdx;
            config.outIdx = foundOutIdx;
            saveConfig(config);
            executarConexao(foundInIdx, foundOutIdx);
        }
    }, 1000); 
}

function executarConexao(inIdx, outIdx, targetSocket = null) {
    const config = loadConfig();
    const searchMonitor = config["loopmidi-monitor"];
    
    // --- O PORTEIRO: Verifica se a porta solicitada (pelo radar ou pela WEB) corresponde ao equipamento esperado ---
    const portas = midiEngine.getAvailablePorts();
    const inputs = portas.inputs || portas; 
    const outputs = portas.outputs || portas;
    
    let inName = inputs[inIdx];
    let outName = outputs[outIdx];

    if (inName && inName.name) inName = inName.name;
    if (outName && outName.name) outName = outName.name;

    const matchesCriteria = (name) => {
        if (!name) return false;
        const lower = String(name).toLowerCase();
        if (searchMonitor) {
            return lower.includes('monitor');
        }
        // Critério específico para Yamaha física: deve ter 'yamaha' e terminar com '-1' (ou conter '-1')
        return lower.includes('yamaha') && lower.includes('-1');
    };

    if (!matchesCriteria(inName) || !matchesCriteria(outName)) {
        if (linhaBuscaAtiva) { process.stdout.write("\n"); linhaBuscaAtiva = false; }
        console.log(`🚫 Conexão bloqueada: A porta [${inName || 'Desconhecida'}] não corresponde aos critérios (${searchMonitor ? 'Monitor' : 'Yamaha'}).`);
        return { success: false, error: searchMonitor ? "A porta não contém 'monitor' no nome." : "Equipamento não é uma Yamaha 01V96." };
    }
    // ------------------------------------------------------------------------------------------------

    const result = midiEngine.connectPorts(inIdx, outIdx, handleMIDIData);

    if (linhaBuscaAtiva) { process.stdout.write("\n"); linhaBuscaAtiva = false; }

    if (result.success) {
        isConnected = true;
        console.log(`✅ Conexão MIDI estabelecida com sucesso! (${inName})`);
        atualizarMenuTray();
        triggerSync(targetSocket);
        io.emit('connectionState', { connected: true });

        // Loop contínuo de requests do Meter (Heartbeat)
        if (global.meterInterval) clearInterval(global.meterInterval);
        lastActivityTime = Date.now();
        
        global.meterInterval = setInterval(() => {
            if (!isConnected) return;

            if (Date.now() - lastActivityTime > 5000) {
                console.log("\n⚠️ Watchdog: Timeout de conexão. A mesa parou de responder.");
                handleDisconnection();
                return;
            }

            // Meters só rodam após sincronia completa
            if (!isFullySynced) return; 

            const sMaster = midiEngine.send(masterMeter.buildRequest());
            const s1 = midiEngine.send([240, 67, 48, 62, 127, 33, 0, 0, 0, 0, 32, 247]); 
            const s2 = midiEngine.send([240, 67, 48, 62, 127, 32, 0, 0, 0, 0, 32, 247]); 
            const s3 = midiEngine.send([240, 67, 48, 62, 26, 33, 0, 0, 0, 0, 32, 247]);  
            const s4 = midiEngine.send([240, 67, 48, 62, 13, 33, 0, 0, 0, 0, 32, 247]);  
            const s5 = midiEngine.send([240, 67, 48, 62, 13, 32, 0, 0, 0, 0, 32, 247]); 
            
            if (!s2 && !s3 && !s4 && !s5 && !sMaster) {
                console.log("\n⚠️ Watchdog: Falha crítica no driver MIDI.");
                handleDisconnection();
            }
        }, 100); 
    } else {
        handleDisconnection(false);
    }
    return result;
}

function handleDisconnection(retry = true) {
    if (!isConnected && retry) return; // Evita duplicação se já estiver buscando
    
    isConnected = false;
    if (global.meterInterval) clearInterval(global.meterInterval);
    if (dummyMeterInterval) {
        clearInterval(dummyMeterInterval);
        dummyMeterInterval = null;
    }
    
    io.emit('connectionState', { connected: false });

    if (retry) {
        console.log("❌ Conexão perdida. Tentando reconectar automaticamente...");
        iniciarBuscaAutomatica();
    }
}

async function triggerSync(targetSocket = null, forceNames = false) {
    if (!isConnected || isSyncing) return;
    const config = loadConfig();
    const delay = config.sync_delay_ms || 35;
    const nameDelay = config.sync_name_delay_ms || 45;

    isSyncing = true;
    isFullySynced = false; // Reseta a flag para pausar meters
    console.log(`🔄 Sincronizando (Delay: ${delay}ms / Nomes: ${nameDelay}ms)...`);
    try {
        await new Promise(r => setTimeout(r, 1000));
        
        for (let i = 0; i < 32; i++) {
            const fReq = protocol.buildRequest('kInputFader/kFader', i);
            const mReq = protocol.buildRequest('kInputChannelOn/kChannelOn', i);
            const sReq = protocol.buildRequest('kSetupSoloChOn/kSoloChOn', i);
            
            if (fReq) midiEngine.send(fReq); await new Promise(r => setTimeout(r, delay)); 
            if (mReq) midiEngine.send(mReq); await new Promise(r => setTimeout(r, delay)); 
            if (sReq) midiEngine.send(sReq); await new Promise(r => setTimeout(r, delay)); 

            // Sincroniza Phase
            midiEngine.send(protocol.buildRequest('kInputPhase/kPhase', i)); await new Promise(r => setTimeout(r, delay));
            
            // Sincroniza Master EQ ON de cada canal
            midiEngine.send(protocol.buildRequest('kInputEQ/kEQOn', i)); await new Promise(r => setTimeout(r, delay));
            midiEngine.send(protocol.buildRequest('kInputEQ/kEQMode', i)); await new Promise(r => setTimeout(r, delay));
            midiEngine.send(protocol.buildRequest('kInputEQ/kEQHPFOn', i)); await new Promise(r => setTimeout(r, delay));
            midiEngine.send(protocol.buildRequest('kInputEQ/kEQLPFOn', i)); await new Promise(r => setTimeout(r, delay));
            
            // Sincroniza Frequências, Ganhos e Q das 4 bandas (Low, LowMid, HiMid, High)
            const bands = ['Low', 'LowMid', 'HiMid', 'Hi'];
            for (const b of bands) {
                midiEngine.send(protocol.buildRequest(`kInputEQ/kEQ${b}F`, i)); await new Promise(r => setTimeout(r, delay));
                midiEngine.send(protocol.buildRequest(`kInputEQ/kEQ${b}G`, i)); await new Promise(r => setTimeout(r, delay));
                midiEngine.send(protocol.buildRequest(`kInputEQ/kEQ${b}Q`, i)); await new Promise(r => setTimeout(r, delay));
            }

            // Requisita também os 8 auxiliares
            for (let a = 1; a <= 8; a++) {
                const auxReq = protocol.buildRequest(`kInputAUX/kAUX${a}Level`, i);
                const auxOnReq = protocol.buildRequest(`kInputAUX/kAUX${a}On`, i);
                if (auxReq) midiEngine.send(auxReq); await new Promise(r => setTimeout(r, delay));
                if (auxOnReq) midiEngine.send(auxOnReq); await new Promise(r => setTimeout(r, delay));
            }

            // 🚨 [CRITICAL SYNC LOGIC] - DINÂMICAS
            // Delays de 15ms entre mensagens e pausa de 600ms a cada 4 canais são MANDATÓRIOS.
            const gateParams = ['kGateOn', 'kGateAttack', 'kGateRange', 'kGateHold', 'kGateDecay', 'kGateThreshold'];
            for (const p of gateParams) {
                const req = protocol.buildRequest(`kInputGate/${p}`, i);
                if (req) midiEngine.send(req);
                await new Promise(r => setTimeout(r, delay));
            }

            const compParams = ['kCompOn', 'kCompAttack', 'kCompRelease', 'kCompRatio', 'kCompGain', 'kCompKnee', 'kCompThreshold'];
            for (const p of compParams) {
                const req = protocol.buildRequest(`kInputComp/${p}`, i);
                if (req) midiEngine.send(req);
                await new Promise(r => setTimeout(r, delay));
            }
            
            // Sincroniza Patch (REATIVADO PARA DEBUG CONFORME PEDIDO)
            midiEngine.send(protocol.buildRequest('kChannelInput/kChannelIn', i)); await new Promise(r => setTimeout(r, delay));

            // Sincroniza Buses 1-8 e Stereo
            midiEngine.send(protocol.buildRequest('kInputBus/kStereo', i)); await new Promise(r => setTimeout(r, delay));
            for (let b = 1; b <= 8; b++) {
                midiEngine.send(protocol.buildRequest(`kInputBus/kBus${b}`, i)); await new Promise(r => setTimeout(r, delay));
            }

            // [CRITICAL] Pausa estratégica a cada 4 canais para alívio do buffer da mesa
            if ((i + 1) % 4 === 0) {
                process.stdout.write("|");
                midiEngine.send(masterMeter.buildRequest()); // Força meter na pausa
                await new Promise(r => setTimeout(r, 600));
            }
        }

        // Sincroniza Mixes (1-8) e Buses (1-8)
        console.log("🔄 Sincronizando Mixes e Buses (Faders + EQ)...");
        const outBands = ['Low', 'LowMid', 'HiMid', 'Hi'];
        for (let i = 0; i < 8; i++) {
            midiEngine.send(protocol.buildRequest('kAUXFader/kFader', i)); await new Promise(r => setTimeout(r, delay));
            midiEngine.send(protocol.buildRequest('kAUXChannelOn/kChannelOn', i)); await new Promise(r => setTimeout(r, delay));
            midiEngine.send(protocol.buildRequest('kBusFader/kFader', i)); await new Promise(r => setTimeout(r, delay));
            midiEngine.send(protocol.buildRequest('kBusChannelOn/kChannelOn', i)); await new Promise(r => setTimeout(r, delay));

            // AUX EQ
            midiEngine.send(protocol.buildRequest('kAUXEQ/kEQOn', i)); await new Promise(r => setTimeout(r, delay));
            for (const b of outBands) {
                midiEngine.send(protocol.buildRequest(`kAUXEQ/kEQ${b}F`, i)); await new Promise(r => setTimeout(r, delay));
                midiEngine.send(protocol.buildRequest(`kAUXEQ/kEQ${b}G`, i)); await new Promise(r => setTimeout(r, delay));
            }

            // BUS EQ
            midiEngine.send(protocol.buildRequest('kBusEQ/kEQOn', i)); await new Promise(r => setTimeout(r, delay));
            for (const b of outBands) {
                midiEngine.send(protocol.buildRequest(`kBusEQ/kEQ${b}F`, i)); await new Promise(r => setTimeout(r, delay));
                midiEngine.send(protocol.buildRequest(`kBusEQ/kEQ${b}G`, i)); await new Promise(r => setTimeout(r, delay));
            }
        }

        // Stereo Master robust sync
        console.log("🔄 Sincronizando Stereo Master (Fader + EQ + Comp)...");
        midiEngine.send(protocol.buildRequest('kStereoFader/kFader', 0)); await new Promise(r => setTimeout(r, delay));
        midiEngine.send(protocol.buildRequest('kStereoChannelOn/kChannelOn', 0)); await new Promise(r => setTimeout(r, delay));
        midiEngine.send(protocol.buildRequest('kStereoAttenuator/kAtt', 0)); await new Promise(r => setTimeout(r, delay));

        // Master EQ
        midiEngine.send(protocol.buildRequest('kStereoEQ/kEQOn', 0)); await new Promise(r => setTimeout(r, delay));
        midiEngine.send(protocol.buildRequest('kStereoEQ/kEQMode', 0)); await new Promise(r => setTimeout(r, delay));
        midiEngine.send(protocol.buildRequest('kStereoEQ/kEQHPFOn', 0)); await new Promise(r => setTimeout(r, delay));
        midiEngine.send(protocol.buildRequest('kStereoEQ/kEQLPFOn', 0)); await new Promise(r => setTimeout(r, delay));
        for (const b of outBands) {
            midiEngine.send(protocol.buildRequest(`kStereoEQ/kEQ${b}F`, 0)); await new Promise(r => setTimeout(r, delay));
            midiEngine.send(protocol.buildRequest(`kStereoEQ/kEQ${b}G`, 0)); await new Promise(r => setTimeout(r, delay));
            midiEngine.send(protocol.buildRequest(`kStereoEQ/kEQ${b}Q`, 0)); await new Promise(r => setTimeout(r, delay));
        }

        // Master Compressor
        const masterCompParams = ['kCompOn', 'kCompAttack', 'kCompRelease', 'kCompRatio', 'kCompGain', 'kCompKnee', 'kCompThreshold'];
        for (const p of masterCompParams) {
            const req = protocol.buildRequest(`kStereoComp/${p}`, 0);
            if (req) midiEngine.send(req);
            await new Promise(r => setTimeout(r, delay));
        }

        await new Promise(r => setTimeout(r, 600)); 
        
        if (targetSocket) {
            targetSocket.emit('sync', stateManager.getState());
        } else {
            io.emit('sync', stateManager.getState());
        }
        console.log("✅ Sincronização de parâmetros concluída!");

        if (forceNames || !hasSyncedNamesThisSession) {
            console.log("📝 [SYNC] Iniciando busca obrigatória de nomes na mesa (1 vez por boot)...");
            await new Promise(r => setTimeout(r, 2000)); 

            for (let i = 0; i < 32; i++) {
                stateManager.setChannelName(i, ""); 

                for (let c = 0; c < 4; c++) {
                    const nameReq = protocol.buildNameRequest(i, c);
                    if (nameReq) midiEngine.send(nameReq);
                    await new Promise(r => setTimeout(r, nameDelay)); 
                }
                
                if (i % 2 === 0) {
                    process.stdout.write(".");
                    await new Promise(r => setTimeout(r, 200)); 
                }
            }
            console.log("\n✅ [SYNC] Carregamento de nomes via MIDI concluído!");
            hasSyncedNamesThisSession = true; 
            saveNames(); 
        } else {
            console.log("⏭️ [SYNC] Nomes já sincronizados nesta sessão. Ignorando busca lenta via MIDI.");
        }

        isFullySynced = true; 
        console.log("🚀 Meters liberados e sincronizados!");

    } finally {
        isSyncing = false;
    }
}


// --- COMUNICAÇÃO WEB (SOCKET.IO) ---

io.on('connection', (socket) => {
    const currentConfig = loadConfig();
    socket.emit('portsList', { available: midiEngine.getAvailablePorts(), savedConfig: currentConfig });
    socket.emit('sync', stateManager.getState());
    socket.emit('connectionState', { connected: isConnected });

    socket.on('requestConnect', async (data) => {
        const config = loadConfig();
        // Se já estivermos conectados na mesma porta, não precisamos disparar um triggerSync global
        if (isConnected && config.inIdx === data.inIdx && config.outIdx === data.outIdx) {
            console.log("🔌 Cliente reconectando, mas MIDI já está ativo nestas portas. Enviando apenas sync local...");
            socket.emit('sync', stateManager.getState());
            socket.emit('connectResult', { success: true });
            return;
        }

        config.inIdx = data.inIdx;
        config.outIdx = data.outIdx;
        saveConfig(config);
        // Se a web pedir para conectar, passa pelo mesmo porteiro!
        const result = executarConexao(data.inIdx, data.outIdx, socket);
        socket.emit('connectResult', result);
    });

    socket.on('forceSync', () => triggerSync(null, true)); // Agora forceSync também força nomes
    
    socket.on('refreshNames', () => {
        console.log("🔄 Solicitação manual de atualização de nomes...");
        triggerSync(null, true);
    });
    
    socket.on('toggleDemo', (data) => {
        const config = loadConfig();
        config.demo_mode = data.enabled;
        saveConfig(config);
        
        if (data.enabled) {
            iniciarDummy();
        } else {
            console.log("🛑 Parando Simulação de Meters...");
            if (dummyMeterInterval) clearInterval(dummyMeterInterval);
            dummyMeterInterval = null;
            
            // Pequeno delay para garantir que a zeragem ocorra após os últimos pulsos
            setTimeout(() => {
                const zeros = new Array(32).fill(0);
                meterDataBuffer = zeros;
                io.emit('meterData', zeros);
                console.log("🧹 Meters zerados com sucesso.");
            }, 100);
        }
    });

    socket.on('updateMeterConfig', (data) => {
        const config = loadConfig();
        config.meter_opacity = data.opacity;
        saveConfig(config);
    });

    socket.on('updateName', async (data) => {
        const { channel, name } = data;
        const s = stateManager.getState();
        if (s.channels[channel] !== undefined) {
            // Atualiza o estado local IMEDIATAMENTE (limita a 4 para ser robusto)
            const limitedName = name.substring(0, 4);
            stateManager.setChannelName(channel, limitedName);
            saveNames(); // Garante o salvamento no JSON

            // --- ENVIO PARA A MESA FÍSICA ---
            if (isConnected) {
                console.log(`📝 Enviando nome para Canal ${channel + 1}: "${limitedName}"`);
                const paddedName = limitedName.padEnd(16, ' ').substring(0, 16);
                
                for (let i = 0; i < 16; i++) {
                    const charCode = paddedName.charCodeAt(i);
                    const msg = protocol.buildNameChange(channel, i, charCode);
                    if (msg) midiEngine.send(msg);
                    await new Promise(r => setTimeout(r, 5));
                }
            }
        }
    });

    socket.on('requestDynamics', (data) => {
        const { channel } = data;
        if (channel === undefined || !isConnected) return;
        
        // Como agora sincronizamos tudo no boot, apenas devolvemos o estado atual do StateManager
        const currentState = stateManager.getState().channels[channel];
        socket.emit('dynamicsState', {
            channel,
            gate: currentState.gate,
            comp: currentState.comp
        });
    });

    socket.on('requestEqAtt', (data) => {
        const { channel } = data;
        if (channel === undefined || !isConnected) return;
        
        const req = protocol.buildRequest('kInputAttenuator/kAtt', channel);
        if (req) midiEngine.send(req);
    });

    // --- INJETOR DE MODS (SYSEX DIRETO) ---
    socket.on('sysex', (rawBytes) => {
        if (!isConnected || !rawBytes) return;
        // Espera um array de números [240, 67, ...]
        midiEngine.send(rawBytes);
    });

    socket.on('control', (data) => {
        if (data.type === 'kChannelInput/kChannelIn') {
            console.log(`🌐 [BROWSER -> SERVER] Mudança de Patch Solicitada: Canal ${data.channel + 1} -> Patch ${data.value}`);
        }

        // Bloqueio Total Offline (COMENTADO PARA DEBUG)
        // if (!isConnected) return;

        // Atualiza o estado na memória do servidor
        stateManager.updateState(data);
        io.emit('update', data);

        const isBinary = data.type.includes('On') || data.type.includes('Solo');
        let converter = isBinary ? protocol.CONVERTERS.onToBytes : protocol.CONVERTERS.faderToBytes;
        
        // Se for EQ Gain (termina em G), Gains em geral, Attenuator ou Dynamics (Threshold/Range), usa conversor de assinado (28-bit)
        if (data.type.toLowerCase().includes('att') || 
            (data.type.includes('EQ/') && data.type.endsWith('G')) ||
            data.type.includes('Gain') ||
            data.type.includes('Threshold') ||
            data.type.includes('Range')) {
            converter = protocol.CONVERTERS.signedToBytes;
        }

        const sysex = protocol.buildChange(data.type, data.channel, data.value, converter);
        if (sysex) {
            const hex = Buffer.from(sysex).toString('hex').toUpperCase();
            console.log(`📤 [MIDI OUT] ${data.type} (CH ${data.channel + 1}): Val ${data.value} -> SysEx: ${hex}`);
            midiEngine.send(sysex);
        }
    });
});

// --- INICIALIZAÇÃO DO SERVIDOR ---
const PORT = process.env.PORT || 4000;
server.listen(PORT, '0.0.0.0', () => {
    const interfaces = os.networkInterfaces();
    const addresses = [];
    for (const k in interfaces) {
        for (const k2 in interfaces[k]) {
            const address = interfaces[k][k2];
            if (address.family === 'IPv4' && !address.internal) addresses.push(address.address);
        }
    }

    console.log(`\n=================================================`);
    console.log(`🚀 SERVIDOR 01V96 BRIDGE ATIVO`);
    console.log(`🌍 Disponível em: http://localhost:${PORT}`);
    addresses.forEach(addr => console.log(`   - Rede: http://${addr}:${PORT}`));
    console.log(`=================================================\n`);

    const config = loadConfig();
    if (config.demo_mode) {
        iniciarDummy();
    } else {
        console.log("ℹ️ [INFO] Modo Demo desativado. Aguardando conexão física com Yamaha...");
    }

    loadNames(); // Carrega nomes do arquivo na inicialização do servidor
    
    // Sempre iniciamos pela busca automática para respeitar a regra do loopmidi-monitor
    setTimeout(() => iniciarBuscaAutomatica(), 1500);
});