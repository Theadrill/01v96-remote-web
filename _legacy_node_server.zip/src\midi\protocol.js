const { COMMAND_BYTES } = require('./dictionary');
const panModule = require('./pan');

const CONVERTERS = {
    faderToBytes: (value) => [0, 0, (value >> 7) & 0x07, value & 0x7F],
    bytesToFader: (bytes) => {
        let val = 0;
        for (let i = 0; i < bytes.length; i++) {
            val = (val << 7) | bytes[i];
        }
        return val;
    },
    bytesToSigned: (bytes) => {
        let val = 0;
        for (let i = 0; i < bytes.length; i++) {
            val = (val << 7) | bytes[i];
        }

        const numBits = bytes.length * 7;
        const signBit = 1 << (numBits - 1);
        const mask = (1 << numBits) - 1;
        if (val & signBit) val -= (mask + 1);
        return val;
    },
    signedToBytes: (value) => {
        let v = Math.round(value);
        if (v < 0) v += 0x10000000;
        return [(v >> 21) & 0x7F, (v >> 14) & 0x7F, (v >> 7) & 0x7F, v & 0x7F];
    },
    signed14ToBytes: (value) => {
        let v = Math.round(value);
        if (v < 0) v += 0x4000;
        return [(v >> 7) & 0x7F, v & 0x7F];
    },
    dynOnToBytes: (isOn) => [0, 0, 0, isOn ? 0 : 1],
    bytesToDynOn: (bytes) => (bytes[bytes.length - 1] === 0),
    onToBytes: (isOn) => [0, 0, 0, isOn ? 1 : 0],
    bytesToOn: (bytes) => !!bytes[bytes.length - 1],
    bytesToChar: (bytes) => String.fromCharCode(bytes[bytes.length - 1] || 32)
};

const HEADER = [240, 67]; // F0 43
const MODEL_ID = 62;      // 3E
const FOOTER = [247];     // F7

function buildChange(commandName, channelIndex, value, converterFunc) {
    const coords = COMMAND_BYTES[commandName];
    if (!coords) return null;
    const [section, group, element, parameter] = coords;
    const bytes = converterFunc(value);
    
    // Tradução de Canal Global -> Local
    let localIndex = channelIndex;
    if (typeof channelIndex === 'number') {
        if (channelIndex >= 60 && channelIndex <= 67) localIndex = 32 + (channelIndex - 60);
        else if (commandName.includes('kAUX') && channelIndex >= 36) localIndex = channelIndex - 36;
        else if (commandName.includes('kBus') && channelIndex >= 44) localIndex = channelIndex - 44;
        else if (commandName.includes('kMatrix') && channelIndex >= 52) localIndex = channelIndex - 52;
        else if (commandName.includes('kStereo')) localIndex = 0;
    } else if (channelIndex === 'master') {
        localIndex = 0;
    }

    return [0xF0, 0x43, 0x10, 0x3E, section, group, element, parameter, localIndex, ...bytes, 0xF7];
}

function buildRequest(commandName, channelIndex) {
    const coords = COMMAND_BYTES[commandName];
    if (!coords) return null;
    const [section, group, element, parameter] = coords;

    let localIndex = channelIndex;
    if (typeof channelIndex === 'number') {
        if (channelIndex >= 60 && channelIndex <= 67) localIndex = 32 + (channelIndex - 60);
        else if (commandName.includes('kAUX') && channelIndex >= 36) localIndex = channelIndex - 36;
        else if (commandName.includes('kBus') && channelIndex >= 44) localIndex = channelIndex - 44;
        else if (commandName.includes('kMatrix') && channelIndex >= 52) localIndex = channelIndex - 52;
        else if (commandName.includes('kStereo')) localIndex = 0;
    } else if (channelIndex === 'master') {
        localIndex = 0;
    }

    return [0xF0, 0x43, 0x30, 0x3E, section, group, element, parameter, localIndex, 0xF7];
}

function buildNameRequest(channelIndex, charIndex) {
    const parameter = 4 + charIndex;
    let element = 4;
    let localCh = channelIndex;

    if (channelIndex >= 60 && channelIndex <= 67) {
        element = 23;
        localCh = Math.floor((channelIndex - 60) / 2);
    } else if (channelIndex >= 36 && channelIndex <= 43) {
        element = 16;
        localCh = channelIndex - 36;
    } else if (channelIndex >= 44 && channelIndex <= 51) {
        element = 15;
        localCh = channelIndex - 44;
    } else if (channelIndex === 52) {
        element = 18;
        localCh = 0;
    }

    // Retornamos ao ID 13 (0x0D) pois é o padrão clássico da 01V96 para Nomes
    return [...HEADER, 48, MODEL_ID, 13, 2, element, parameter, localCh, ...FOOTER];
}

function buildNameChange(channelIndex, charIndex, charCode) {
    const parameter = 4 + charIndex;
    let element = 4;
    let localCh = channelIndex;

    if (channelIndex >= 36 && channelIndex <= 43) {
        element = 16;
        localCh = channelIndex - 36;
    } else if (channelIndex >= 44 && channelIndex <= 51) {
        element = 15;
        localCh = channelIndex - 44;
    } else if (channelIndex === 52) {
        element = 18;
        localCh = 0;
    }

    // F0 43 10 3E 0D 02 [ELEMENT] [PARAM] [CH] 00 00 00 [VAL] F7
    return [...HEADER, 16, MODEL_ID, 13, 2, element, parameter, localCh, 0, 0, 0, charCode, ...FOOTER];
}

function parseIncoming(message) {
    if (!message || message.length < 8) return null;

    // Ignora se não for uma mensagem de dados/mudança (0x1n).
    // Isso evita processar nossos próprios pedidos (Requests 0x3n) que o loopMIDI ecoa de volta.
    if ((message[2] & 0xF0) !== 0x10) return null;

    // --- PRIORIDADE 0: PAN ---
    // Intercepta antes de qualquer outro parser pois usa seção 0x7F / 0x4E
    // que não faz parte das seções padrão (13, 26, 127, 1).
    const panResult = panModule.parsePanMessage(message);
    if (panResult) return panResult;

    const group = message[5];
    const parameter = message[7];
    const channel = message[8];

    const element = message[6];

    // 🚨 [CRITICAL SYNC LOGIC] - METER DATA
    // Captura mensagens de Metering Universal (Seções 13, 26, 127) da Yamaha 01V96.
    // Para os canais 1-32, a Yamaha envia mensagens longas (>20 bytes) com os "steps" (0-31) no High Byte de cada canal.
    const isMasterMeter = (message.length === 14) && (message[4] === 13) && (message[5] === 33) && (message[6] === 4);
    const isUniversalMeter = (message.length > 20) &&
                    (message[4] === 13 || message[4] === 26 || message[4] === 127) &&
                    (group === 33 || group === 32 || group === 82);

    if (isMasterMeter || isUniversalMeter) {
        let levels = {};
        const dataStart = 9;
        const isMasterPoint = (message[6] === 4);
        
        const dataBytesAvailable = (message.length - 1) - dataStart;
        const numChannelsInMessage = Math.floor(dataBytesAvailable / 2);

        for (let i = 0; i < numChannelsInMessage; i++) {
            const idx = dataStart + (i * 2);
            levels[channel + i] = message[idx] || 0;
        }
        return { type: 'METER_DATA', levels, group: message[5], isMaster: isMasterPoint };
    }

    if (message[4] === 13 && message[5] === 127) return null;

    const dataBytes = message.slice(9, -1);

    // 🚨 [CRITICAL SYNC LOGIC] - PARAMETER CHANGES
    // Suporta ID 13, 26 e 127 (Universal) que são os comandos de mudança de parâmetro da 01V96.
    if (message[4] === 13 || message[4] === 127 || message[4] === 26 || message[4] === 1) {

        // --- PRIORIDADE 1: NOMES DE CANAIS E CENAS ---
        // Se o elemento for um dos IDs de nome (4, 15, 16, 18, 23) e o parâmetro estiver no range de caracteres (4-19)
        if ([4, 15, 16, 18, 23].includes(element) && parameter >= 4 && parameter <= 19) {
            const charIndex = parameter - 4;
            const charCode = dataBytes[dataBytes.length - 1];
            const char = String.fromCharCode(charCode);

            // Traduz o canal local do módulo de volta para o ID global do sistema
            let channelIndex = channel;
            if (element === 4) channelIndex = channel; // 0-31 (CH1-32)
            else if (element === 23) channelIndex = 60 + (channel * 2); // ST IN 1-4
            else if (element === 16) channelIndex = 36 + channel; // AUX 1-8
            else if (element === 15) channelIndex = 44 + channel; // BUS 1-8
            else if (element === 18) channelIndex = 52; // MASTER

            // 🚨 [STRICT CHECK] Apenas Seção 13 (Current) e Grupo 2 contêm nomes de canais nesta estrutura de elemento/parâmetro
            if (message[4] !== 13 || group !== 2) return null;

            return {
                type: 'updateNameChar',
                channel: channelIndex,
                charIndex: charIndex,
                char: char
            };
        }

        // EQ Parsing: Input (32, 33), Bus (46), AUX (60), Stereo (82)
        // Note: Bus EQ (46) collides with Solo (46) when requested, so we check message[5] === 1 (Param Change)
        const eqMap = { 32: 'kInput', 33: 'kInput', 46: 'kBus', 60: 'kAUX', 82: 'kStereo' };
        if (eqMap[element] && parameter <= 15 && message[5] === 1) {
            const eqKeys = [
                'kEQMode', 'kEQLowQ', 'kEQLowF', 'kEQLowG', 'kEQHPFOn',
                'kEQLowMidQ', 'kEQLowMidF', 'kEQLowMidG',
                'kEQHiMidQ', 'kEQHiMidF', 'kEQHiMidG',
                'kEQHiQ', 'kEQHiF', 'kEQHiG',
                'kEQLPFOn', 'kEQOn'
            ];
            const prefix = eqMap[element];
            const key = eqKeys[parameter];
            const converter = (key.endsWith('G')) ? CONVERTERS.bytesToSigned : CONVERTERS.bytesToFader;
            
            let globalCh = channel;
            if (prefix === 'kAUX') globalCh = 36 + channel;
            else if (prefix === 'kBus') globalCh = 44 + channel;
            else if (prefix === 'kStereo') globalCh = 'master';

            return { type: `${prefix}EQ/${key}`, channel: globalCh, value: converter(dataBytes) };
        }

        // Input GATE (Element 30)
        if (element === 30) {
            const gateKeys = [
                'kGateOn', 'kGateLink', 'kGateKeyIn', 'kGateKeyAUX', 'kGateKeyCh',
                'kGateType', 'kGateAttack', 'kGateRange', 'kGateHold', 'kGateDecay', 'kGateThreshold'
            ];
            const key = gateKeys[parameter];
            let converter = CONVERTERS.bytesToFader;
            if (key === 'kGateThreshold' || key === 'kGateRange') converter = CONVERTERS.bytesToSigned;
            if (key === 'kGateOn' || key === 'kGateLink') converter = CONVERTERS.bytesToOn;
            return { type: `kInputGate/${key}`, channel, value: converter(dataBytes) };
        }

        // Compressor Parsing (Input 31, Bus 45, AUX 59, Matrix 71, Stereo 81)
        const compMap = { 31: 'kInput', 45: 'kBus', 59: 'kAUX', 71: 'kMatrix', 81: 'kStereo' };
        if (compMap[element]) {
            const compKeys = [
                'kCompLocComp', 'kCompOn', 'kCompLink', 'kCompType',
                'kCompAttack', 'kCompRelease', 'kCompRatio', 'kCompGain', 'kCompKnee', 'kCompThreshold'
            ];
            const key = compKeys[parameter];
            const prefix = compMap[element];
            let converter = CONVERTERS.bytesToFader;
            if (key === 'kCompThreshold') converter = CONVERTERS.bytesToSigned;
            if (key === 'kCompOn' || key === 'kCompLink') converter = CONVERTERS.bytesToOn;

            let globalCh = channel;
            if (prefix === 'kAUX') globalCh = 36 + channel;
            else if (prefix === 'kBus') globalCh = 44 + channel;
            else if (prefix === 'kMatrix') globalCh = 52 + channel;
            else if (prefix === 'kStereo') globalCh = 'master';

            return { type: `${prefix}Comp/${key}`, channel: globalCh, value: converter(dataBytes) };
        }

        // Bus Assign (Element 34)
        if (element === 34) {
            if (parameter === 0) {
                return { type: 'kInputBus/kStereo', channel, value: CONVERTERS.bytesToOn(dataBytes) };
            }
            if (parameter >= 3 && parameter <= 10) {
                return { type: `kInputBus/kBus${parameter - 2}`, channel, value: CONVERTERS.bytesToOn(dataBytes) };
            }
        }

        // Suporte a Cena (Section 127 - Group 1)
        if (message[4] === 127 && message[5] === 1) {
            // Número da Cena (Element 0)
            if (element === 0 && parameter === 0) {
                const val = dataBytes[dataBytes.length - 1];
                console.log(`🎯 [SCENE SYNC] Número recebido (Sec 127): ${val}`);
                return { type: 'kSceneNumber', value: val };
            }
            // Nome da Cena (Element 1)
            if (element === 1 && parameter >= 0 && parameter <= 15) {
                const char = String.fromCharCode(dataBytes[dataBytes.length - 1] || 32);
                console.log(`📝 [SCENE CHAR] Idx:${parameter} Char:${char}`);
                return {
                    type: 'updateSceneChar',
                    charIndex: parameter,
                    char: char
                };
            }
        }

        // Suporte a Cena (Número - Fallback Section 13)
        if (message[4] === 13 && message[5] === 4 && element === 10 && parameter === 0) {
            const val = dataBytes[dataBytes.length - 1];
            console.log(`🎯 [SCENE SYNC] Número recebido (Sec 13): ${val}`);
            return { type: 'kSceneNumber', value: val };
        }

        // Tradução de Canal para Faders/On (ST IN mapping)
        let finalCh = channel;
        if (channel >= 32 && channel <= 39) finalCh = 60 + (channel - 32);

        // Input Faders / On / Solo / Name / Attenuator etc
        if (element === 28) return { type: 'kInputFader/kFader', channel: finalCh, value: CONVERTERS.bytesToFader(dataBytes) };
        if (element === 26) return { type: 'kInputChannelOn/kChannelOn', channel: finalCh, value: CONVERTERS.bytesToOn(dataBytes) };
        if (element === 29) return { type: 'kInputAttenuator/kAtt', channel: finalCh, value: CONVERTERS.bytesToSigned(dataBytes) };

        // Mix (AUX) Master Faders / ON
        if (element === 57) return { type: 'kAUXFader/kFader', channel, value: CONVERTERS.bytesToFader(dataBytes) };
        if (element === 54) return { type: 'kAUXChannelOn/kChannelOn', channel, value: CONVERTERS.bytesToOn(dataBytes) };

        // Bus Master Faders / ON
        if (element === 43) return { type: 'kBusFader/kFader', channel, value: CONVERTERS.bytesToFader(dataBytes) };
        if (element === 41) return { type: 'kBusChannelOn/kChannelOn', channel, value: CONVERTERS.bytesToOn(dataBytes) };

        // Master (Stereo) Fader e ON
        if (element === 79 && message[7] === 0) return { type: 'kStereoFader/kFader', channel: 'master', value: CONVERTERS.bytesToFader(dataBytes) };
        if (element === 77 && message[7] === 0) return { type: 'kStereoChannelOn/kChannelOn', channel: 'master', value: CONVERTERS.bytesToOn(dataBytes) };

        // Aux Sends (Element 35)
        if (element === 35) {
            const auxIdx = Math.floor(parameter / 3) + 1;
            const offset = parameter % 3;
            if (offset === 0) return { type: `kInputAUX/kAUX${auxIdx}On`, channel, value: CONVERTERS.bytesToOn(dataBytes) };
            if (offset === 2) return { type: `kInputAUX/kAUX${auxIdx}Level`, channel, value: CONVERTERS.bytesToFader(dataBytes) };
        }

        // Solo
        if (message[5] === 3 && element === 46) {
            return { type: 'kSetupSoloChOn/kSoloChOn', channel, value: CONVERTERS.bytesToOn(dataBytes) };
        }

        // Input Patch (Element ID 13, Element 2, Param 1, Sub 0)
        if (message[4] === 13 && message[5] === 2 && element === 1 && parameter === 0) {
            return { type: 'kChannelInput/kChannelIn', channel, value: CONVERTERS.bytesToFader(dataBytes), raw: message };
        }

        // Channel Pair (Element 24)
        if (element === 24 && parameter === 0) {
            return { type: 'kInputPair/kPair', channel, value: dataBytes[dataBytes.length - 1] };
        }
    }

    return null;
}

module.exports = { COMMAND_BYTES, CONVERTERS, buildChange, buildRequest, buildNameRequest, buildNameChange, parseIncoming };
