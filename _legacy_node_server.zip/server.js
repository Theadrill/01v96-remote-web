// Termux workaround
const os = require('os');
os.networkInterfaces = () => {
  return {
    lo: [
      {
        address: '127.0.0.1',
        netmask: '255.0.0.0',
        family: 'IPv4',
        mac: '00:00:00:00:00:00',
        internal: true,
        cidr: '127.0.0.1/8'
      }
    ]
  };
};

// ============================================================================
// server.js — Orquestrador Principal do 01V96 Bridge Server
// ============================================================================
// Ponto de entrada do servidor. Responsável por:
// 1. Inicializar o sistema de logs (console -> file)
// 2. Importar módulos do core (MIDI, protocolo, cenas, estado, meters)
// 3. Criar servidor Express + HTTP + Socket.IO
// 4. Montar o objeto de contexto compartilhado (ctx) com todo estado global
// 5. Inicializar subsistemas na ordem correta:
//    - Config/Nomes/Steps (config.js)
//    - Bandeja do sistema (systray.js)
//    - Handlers MIDI (midi-handler.js)
//    - Gerenciamento de conexão (connection.js)
//    - Handlers Socket.IO (socket-handler.js)
//    - Sistema DMX (dmx.js)
// 6. Subir o servidor HTTP na porta configurada
// 7. Iniciar busca automática de mesa ou modo demo
// ============================================================================

// Node.js built-in modules
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const { exec, spawn } = require('child_process');

// --- INICIALIZAÇÃO DO LOGGER ---
const { setupLogger, overrideConsole } = require('./src/utils/logger');

const logger = setupLogger();
const logInfo = logger.info.bind(logger);
const logError = logger.error.bind(logger);

overrideConsole(logInfo, logError);

console.log('🚀 [SERVER] Iniciando servidor e sistema de logs...');
console.log('📂 [SERVER] Log gravando em:', path.join(__dirname, 'log', 'server_log.txt'));

// --- DETECÇÃO DE PLATAFORMA ---
const platform = require('./src/utils/platform');

// --- IMPORTAÇÃO DOS MÓDULOS CORE ---
// MidiPipeline legacy removed — use SyncManager instead
const midiEngine = require('./src/midi/midi-engine');
const protocol = require('./src/midi/protocol');
const stateManager = require('./src/state/state-manager');
const dummy = require('./src/state/meter_dummy');
const masterMeter = require('./src/state/master-meter');
const sceneManager = require('./src/state/scene_manager');
const SyncManager = require('./src/network/sync-manager');
const pairModule = require('./src/state/pair');

// --- SETUP DO SERVIDOR WEB ---
const app = express();
const server = http.createServer(app);
const io = new Server(server);

// ============================================================================
// OBJETO DE CONTEXTO COMPARTILHADO (ctx)
// ============================================================================
// Todos os subsistemas leem/escrevem neste objeto, eliminando variáveis
// globais e permitindo inicialização explícita na ordem correta.
// ============================================================================

const ctx = {
    // Raiz do projeto (__dirname do server.js)
    rootDir: __dirname,

    // Logger
    logInfo,
    logError,

    // Servidor Web
    io,
    httpServer: server,

    // Variáveis Globais de Estado
    isConnected: false,          // Conexão MIDI ativa com a mesa
    isDemoMode: false,           // Modo demo (simulação sem mesa física)
    isSyncing: false,            // Flag para evitar múltiplas sincronias simultâneas
    isFullySynced: false,        // Flag para liberar os meters apenas após carga total

    // Buffers e timers de meter
    meterDataBuffer: new Array(64).fill(0),
    lastMeterTime: 0,            // Throttle de emissão de meters baseado em FPS
    lastActivityTime: 0,         // Timestamp da última mensagem recebida da mesa (watchdog)

    // Portas e busca
    buscaInterval: null,
    linhaBuscaAtiva: false,

    // Modo demo
    dummyMeterInterval: null,

    // Bandeja do sistema
    systrayInstance: null,
    isTrayReady: false,

    // Timers de debounce para nomes
    nameUpdateTimers: new Map(),

    // SyncManager (instanciado sob demanda na conexão)
    syncManager: null,

    // Configurações carregadas do config.json
    configConstants: {},

    // Módulos core (referências imutáveis)
    midiEngine,
    protocol,
    stateManager,
    dummy,
    masterMeter,
    sceneManager,
    SyncManager,
    pairModule
};

process.title = "01V96-BRIDGE-SERVER";

let restartInProgress = false;

function restartServer(source = 'desconhecida') {
    if (restartInProgress) return;
    restartInProgress = true;

    console.log(`\n🔁 [SERVER] Reinício solicitado via ${source}. Subindo novo processo...`);
    ctx.io.emit('serverRestarting');

    let replacementStarted = false;

    const startReplacementProcess = () => {
        if (replacementStarted) return;
        replacementStarted = true;

        const isWindows = process.platform === 'win32';
        const command = isWindows ? 'wscript.exe' : process.execPath;
        const args = isWindows
            ? ['//B', '//Nologo', path.join(ctx.rootDir, 'run_hidden.vbs')]
            : [path.join(ctx.rootDir, 'server.js')];

        const child = spawn(command, args, {
            cwd: ctx.rootDir,
            detached: true,
            stdio: 'ignore',
            env: process.env,
            windowsHide: true
        });
        child.unref();
    };

    const exitCurrentProcess = () => {
        try {
            if (ctx.midiEngine && ctx.midiEngine.close) ctx.midiEngine.close();
        } catch (error) {
            console.log('⚠️ [SERVER] Falha ao fechar MIDI durante reinício:', error.message);
        }

        try {
            if (ctx.systrayInstance && ctx.systrayInstance.kill) ctx.systrayInstance.kill();
        } catch (error) {
            console.log('⚠️ [SERVER] Falha ao fechar systray durante reinício:', error.message);
        }

        process.exit(0);
    };

    ctx.io.close(() => {
        ctx.httpServer.close(() => {
            console.log('✅ [SERVER] HTTP encerrado. Finalizando processo antigo.');
            startReplacementProcess();
            exitCurrentProcess();
        });
    });

    setTimeout(() => {
        startReplacementProcess();
        exitCurrentProcess();
    }, 3000);
}

ctx.restartServer = restartServer;

// --- INICIALIZAÇÃO DOS SUBSISTEMAS (ordem importa!) ---

// 1. Gerenciamento de configurações, nomes e steps
const { initConfig } = require('./src/core/config');
initConfig(ctx);

// Carregar nomes salvos imediatamente para que os clients vejam os nomes
// mesmo antes da sincronização completa com a mesa física.
ctx.loadNames();
// Carregar constantes de configuração
ctx.loadConfigConstants();

ctx.loadStepsCalibration();

// 3. Handler de dados MIDI (callback do midiEngine + modo demo)
const { initMidiHandler } = require('./src/midi/midi-handler');
initMidiHandler(ctx);

// 4. Gerenciamento de conexão/busca/sincronia
const { initConnection } = require('./src/network/connection');
initConnection(ctx);

// 5. Handlers Socket.IO (comunicação com frontend)
const { initSocketHandler } = require('./src/network/socket-handler');
initSocketHandler(ctx);

// 6. Sistema de iluminação DMX (ArtNet + Lumikit)
const { initDmx } = require('./src/dmx/dmx');
initDmx(ctx);

// --- ROTAS EXPRESS ---

app.use(express.static('public'));

// Os endpoints /api/names e /api/proxy foram movidos para src/api/macros.js
// para centralizar a lógica de API de macros e permitir acesso ao estado live.
const macroRoutes = require('./src/api/macros');
app.use('/api', macroRoutes);

// --- REGISTRO DOS HANDLERS SOCKET.IO ---
ctx.setupSocketHandlers();

// --- INICIALIZAÇÃO DO SERVIDOR ---
const PORT = process.env.PORT || 4000;
server.listen(PORT, '0.0.0.0', () => {
    const interfaces = os.networkInterfaces();
    const addresses = [];
    for (const k in interfaces) {
        for (const k2 in interfaces[k]) {
            const address = interfaces[k][k2];
            if (address.family === 'IPv4' && !address.internal) addresses.push(address.address);
        }
    }

    console.log(`\n=================================================`);
    console.log(`🚀 SERVIDOR 01V96 BRIDGE ATIVO`);
    console.log(`🌍 Disponível em: http://localhost:${PORT}`);
    addresses.forEach(addr => console.log(`   - Rede: http://${addr}:${PORT}`));
    console.log(`=================================================\n`);

    const config = ctx.loadConfig();

    // --- PLATFORM OVERRIDES ---
    // DMX: desabilitar se plataforma não suporta, mesmo que config esteja true
    let dmxEnabled = config.sistema_iluminacao === true;
    if (dmxEnabled && !platform.supportsDmx) {
        console.log(`ℹ️ [PLATFORM] DMX não suportado nesta plataforma. Ignorando.`);
        dmxEnabled = false;
    }

    // Systray: desabilitar se plataforma não suporta, mesmo que config esteja habilitando
    let systrayEnabled = config.disable_systray !== true;
    if (systrayEnabled && !platform.supportsSystray) {
        console.log(`ℹ️ [PLATFORM] Systray não suportado nesta plataforma. Ignorando.`);
        systrayEnabled = false;
    }

    // MIDI nativo: apenas avisa se não houver suporte, sem forçar demo mode
    if (!platform.hasNativeMidi) {
        console.log(`ℹ️ [PLATFORM] MIDI nativo indisponível nesta plataforma.`);
        console.log(`ℹ️ [PLATFORM] Use demo_mode:true no config.json para simular, ou aguarde a ponte MIDI over Network.`);
    }

    // --- APLICA DECISÕES ---
    if (config.demo_mode) {
        ctx.isDemoMode = true;
        ctx.iniciarDummy();
        console.log('ℹ️ [DEMO] Modo Demo ativo — busca na USB desativada.');
    } else {
        console.log("ℹ️ [INFO] Modo Demo desativado. Aguardando conexão física com Yamaha...");
    }

    // Busca automática na USB apenas se NÃO estiver em demo mode
    if (!config.demo_mode) {
        setTimeout(() => ctx.iniciarBuscaAutomatica(), ctx.configConstants.boot_delay_ms);

        // --- AUTO-START DMX (INTELIGENTE) ---
        if (dmxEnabled) {
            setTimeout(() => {
                console.log('💡 [BOOT] Verificando sistema de iluminação...');
                ctx.startDmxApp(false);
            }, ctx.configConstants.dmx_boot_delay_ms);
        } else {
            console.log('ℹ️ [DMX] Iluminação desligada (config ou plataforma não suporta).');
        }
    }

    // Bandeja do sistema (ícone no tray)
    if (systrayEnabled) {
        try {
            const { initSystray } = require('./src/utils/systray');
            initSystray(ctx);
        } catch (error) {
            console.log('⚠️ [SYSTRAY] Falha ao carregar a bandeja do sistema:', error.message);
        }
    } else {
        console.log('ℹ️ [SERVER] Systray desativada (config ou plataforma não suporta).');
    }

    // Abrir o navegador automaticamente apenas se a flag estiver ativa
    if (config.open_browser_startup !== false) {
        const url = `http://localhost:${PORT}`;
        exec(`start ${url}`);
    } else {
        console.log(`ℹ️ [CONFIG] Auto-abertura do navegador desativada. Acesse manualmente: http://localhost:${PORT}`);
    }
});
