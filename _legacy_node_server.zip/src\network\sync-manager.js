const protocol = require('../midi/protocol');
const stateManager = require('../state/state-manager');
const masterMeter = require('../state/master-meter');
const panModule = require('../midi/pan');

class SyncManager {
    constructor(scheduler, io, sceneManager) {
        this.scheduler = scheduler;
        this.io = io;
        this.sceneManager = sceneManager;
        this.isSyncing = false;
        this.isFullySynced = true;
        this.hasSyncedNamesThisSession = false;
        this.onSyncComplete = null;
    }

    async fire(targetSocket = null, forceNames = false, type = 'normal') {
        if (this.isSyncing) return;

        this.isSyncing = true;
        this.isFullySynced = false;

        if (this.io) {
            this.io.emit('syncStatus', { active: true, type: type });
        }

        // Sincroniza a biblioteca de cenas antes de pedir os parâmetros dos faders/EQ
        if (this.sceneManager && this.scheduler && this.scheduler.midiEngine) {
            await this.sceneManager.fetchScenes(this.scheduler.midiEngine);
        }

        this._queueAllParams(forceNames, targetSocket);
    }

    // Sync apenas de parâmetros de canal — NÃO baixa a biblioteca de cenas.
    // Usar após recall de cena, onde as cenas já estão em cache e um novo
    // fetchScenes() criaria um gargalo MIDI competindo com os requests de canal.
    fireParamsOnly(targetSocket = null, forceNames = false, type = 'is_scene') {
        if (this.isSyncing) return;

        this.isSyncing = true;
        this.isFullySynced = false;

        if (this.io) {
            this.io.emit('syncStatus', { active: true, type: type });
        }

        // Aquece o scheduler com 64 stop requests (~1 segundo de warmup) antes dos params.
        // Isso garante que a CPU da mesa saiu totalmente do estado de processamento da cena.
        for (let i = 0; i < 64; i++) {
            this.scheduler.enqueue(masterMeter.buildStopRequest(), 1);
        }

        // REDUNDÂNCIA: Pede fader e on dos primeiros 4 canais antecipadamente.
        // Se a mesa ainda estiver "acordando", esses podem falhar, mas o loop principal 
        // logo abaixo tentará novamente, aumentando a chance de sucesso no Canal 1.
        for (let i = 0; i < 4; i++) {
            this.scheduler.enqueue(protocol.buildRequest('kInputFader/kFader', i), 1);
            this.scheduler.enqueue(protocol.buildRequest('kInputChannelOn/kChannelOn', i), 1);
        }
        
        // ST IN (60-67)
        for (let i = 60; i <= 67; i++) {
            this.scheduler.enqueue(protocol.buildRequest('kInputFader/kFader', i), 1);
            this.scheduler.enqueue(protocol.buildRequest('kInputChannelOn/kChannelOn', i), 1);
        }

        this._queueAllParams(forceNames, targetSocket);
    }

    _queueAllParams(forceNames, targetSocket) {
        const priority = 1;

        // Para os meters antes do sync
        this.scheduler.enqueue(masterMeter.buildStopRequest(), priority);

        // [PRIORIDADE] Pan de todos os canais de input, ST IN e Master
        const panRequests = panModule.buildPanSyncRequests();
        for (const req of panRequests) {
            this.scheduler.enqueue(req, priority);
        }

        // Fader e On do Stereo Master
        this.scheduler.enqueue(protocol.buildRequest('kStereoFader/kFader', 0), priority);

        // 32 Canais de Input
        for (let i = 0; i < 32; i++) {
            this.scheduler.enqueue(protocol.buildRequest('kInputFader/kFader', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kInputChannelOn/kChannelOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kSetupSoloChOn/kSoloChOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kInputPhase/kPhase', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kInputAttenuator/kAtt', i), priority);

            // EQ
            this.scheduler.enqueue(protocol.buildRequest('kInputEQ/kEQOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kInputEQ/kEQMode', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kInputEQ/kEQHPFOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kInputEQ/kEQLPFOn', i), priority);
            ['Low', 'LowMid', 'HiMid', 'Hi'].forEach(b => {
                this.scheduler.enqueue(protocol.buildRequest(`kInputEQ/kEQ${b}F`, i), priority);
                this.scheduler.enqueue(protocol.buildRequest(`kInputEQ/kEQ${b}G`, i), priority);
                this.scheduler.enqueue(protocol.buildRequest(`kInputEQ/kEQ${b}Q`, i), priority);
            });

            // AUX Sends (8 bandas)
            for (let a = 1; a <= 8; a++) {
                this.scheduler.enqueue(protocol.buildRequest(`kInputAUX/kAUX${a}Level`, i), priority);
                this.scheduler.enqueue(protocol.buildRequest(`kInputAUX/kAUX${a}On`, i), priority);
            }

            // Gate
            ['kGateOn', 'kGateAttack', 'kGateRange', 'kGateHold', 'kGateDecay', 'kGateThreshold'].forEach(p => {
                this.scheduler.enqueue(protocol.buildRequest(`kInputGate/${p}`, i), priority);
            });

            // Comp
            ['kCompOn', 'kCompAttack', 'kCompRelease', 'kCompRatio', 'kCompGain', 'kCompKnee', 'kCompThreshold'].forEach(p => {
                this.scheduler.enqueue(protocol.buildRequest(`kInputComp/${p}`, i), priority);
            });

            // Patch e Bus Assignments
            this.scheduler.enqueue(protocol.buildRequest('kChannelInput/kChannelIn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kInputBus/kStereo', i), priority);
            for (let b = 1; b <= 8; b++) {
                this.scheduler.enqueue(protocol.buildRequest(`kInputBus/kBus${b}`, i), priority);
            }

            // Pair Status (solicitado apenas para canais ímpares da mesa/pares de índice, ex: CH1, CH3...)
            if (i % 2 === 0) {
                this.scheduler.enqueue(protocol.buildRequest('kInputPair/kPair', i), priority);
            }

            // Nomes de canais (intercalado um por um se necessário)
            if (forceNames || !this.hasSyncedNamesThisSession) {
                for (let c = 0; c < 4; c++) {
                    this.scheduler.enqueue(protocol.buildNameRequest(i, c), priority);
                }
            }
        }
        
        // ST IN 1-4 (Canais 32-39)
        for (let i = 32; i < 40; i++) {
            this.scheduler.enqueue(protocol.buildRequest('kInputFader/kFader', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kInputChannelOn/kChannelOn', i), priority);
        }
        
        // Nomes dos ST IN (60, 62, 64, 66)
        if (forceNames || !this.hasSyncedNamesThisSession) {
            for (let i = 0; i < 4; i++) {
                const globalId = 60 + (i * 2);
                for (let c = 0; c < 4; c++) {
                    this.scheduler.enqueue(protocol.buildNameRequest(globalId, c), priority);
                }
            }
        }


        // AUX Masters e Bus Masters (8 cada) — Fader, On, EQ e Compressor
        for (let i = 0; i < 8; i++) {
            // AUX (Mix)
            this.scheduler.enqueue(protocol.buildRequest('kAUXFader/kFader', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kAUXChannelOn/kChannelOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kAUXEQ/kEQOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kAUXEQ/kEQHPFOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kAUXEQ/kEQLPFOn', i), priority);
            ['Low', 'LowMid', 'HiMid', 'Hi'].forEach(b => {
                this.scheduler.enqueue(protocol.buildRequest(`kAUXEQ/kEQ${b}F`, i), priority);
                this.scheduler.enqueue(protocol.buildRequest(`kAUXEQ/kEQ${b}G`, i), priority);
                this.scheduler.enqueue(protocol.buildRequest(`kAUXEQ/kEQ${b}Q`, i), priority);
            });
            ['kCompOn', 'kCompAttack', 'kCompRelease', 'kCompRatio', 'kCompGain', 'kCompKnee', 'kCompThreshold'].forEach(p => {
                this.scheduler.enqueue(protocol.buildRequest(`kAUXComp/${p}`, i), priority);
            });

            // Bus
            this.scheduler.enqueue(protocol.buildRequest('kBusFader/kFader', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kBusChannelOn/kChannelOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kBusEQ/kEQOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kBusEQ/kEQHPFOn', i), priority);
            this.scheduler.enqueue(protocol.buildRequest('kBusEQ/kEQLPFOn', i), priority);
            ['Low', 'LowMid', 'HiMid', 'Hi'].forEach(b => {
                this.scheduler.enqueue(protocol.buildRequest(`kBusEQ/kEQ${b}F`, i), priority);
                this.scheduler.enqueue(protocol.buildRequest(`kBusEQ/kEQ${b}G`, i), priority);
                this.scheduler.enqueue(protocol.buildRequest(`kBusEQ/kEQ${b}Q`, i), priority);
            });
            ['kCompOn', 'kCompAttack', 'kCompRelease', 'kCompRatio', 'kCompGain', 'kCompKnee', 'kCompThreshold'].forEach(p => {
                this.scheduler.enqueue(protocol.buildRequest(`kBusComp/${p}`, i), priority);
            });
        }

        // Stereo Master completo
        this.scheduler.enqueue(protocol.buildRequest('kStereoFader/kFader', 0), priority);
        this.scheduler.enqueue(protocol.buildRequest('kStereoChannelOn/kChannelOn', 0), priority);
        this.scheduler.enqueue(protocol.buildRequest('kStereoAttenuator/kAtt', 0), priority);
        this.scheduler.enqueue(protocol.buildRequest('kStereoEQ/kEQOn', 0), priority);
        ['Low', 'LowMid', 'HiMid', 'Hi'].forEach(b => {
            this.scheduler.enqueue(protocol.buildRequest(`kStereoEQ/kEQ${b}F`, 0), priority);
            this.scheduler.enqueue(protocol.buildRequest(`kStereoEQ/kEQ${b}G`, 0), priority);
            this.scheduler.enqueue(protocol.buildRequest(`kStereoEQ/kEQ${b}Q`, 0), priority);
        });
        ['kCompOn', 'kCompAttack', 'kCompRelease', 'kCompRatio', 'kCompGain', 'kCompKnee', 'kCompThreshold'].forEach(p => {
            this.scheduler.enqueue(protocol.buildRequest(`kStereoComp/${p}`, 0), priority);
        });

        // Nomes das Saídas: AUX 36-43, Bus 44-51, Master 52
        if (forceNames || !this.hasSyncedNamesThisSession) {
            const outIndices = [];
            for (let i = 36; i <= 43; i++) outIndices.push(i);
            for (let i = 44; i <= 51; i++) outIndices.push(i);
            outIndices.push(52);
            for (const idx of outIndices) {
                for (let c = 0; c < 8; c++) {
                    this.scheduler.enqueue(protocol.buildNameRequest(idx, c), priority);
                }
            }
        }

        this.hasSyncedNamesThisSession = true;

        // Registra callback para quando a q1 esvaziar
        this.scheduler.onQ1Empty = () => {
            this._onQueueEmpty(targetSocket);
        };
    }

    _onQueueEmpty(targetSocket) {
        this._finishSync(targetSocket, '[OK] [SyncManager] Sincronização concluída!');
    }

    _finishSync(targetSocket = null, logMsg = '') {
        this.isSyncing = false;
        this.isFullySynced = true;

        if (this.io) {
            this.io.emit('syncStatus', { active: false });
            this.io.emit('sync', stateManager.getState());
        }

        if (targetSocket && typeof targetSocket.emit === 'function') {
            targetSocket.emit('sync', stateManager.getState());
        }

        if (logMsg) console.log(logMsg);

        if (this.onSyncComplete) {
            this.onSyncComplete();
        }
    }

    // Sync apenas de nomes (para o evento 'refreshNames' do socket)
    syncNamesOnly() {
        if (this.isSyncing) return;

        this.isSyncing = true;
        this.isFullySynced = false;

        if (this.io) {
            this.io.emit('syncStatus', { active: true, type: 'is_scene' });
        }

        this.scheduler.enqueue(masterMeter.buildStopRequest(), 1);

        for (let i = 0; i < 32; i++) {
            for (let c = 0; c < 4; c++) {
                this.scheduler.enqueue(protocol.buildNameRequest(i, c), 1);
            }
        }

        // Nomes dos ST IN (60, 62, 64, 66)
        for (let i = 0; i < 4; i++) {
            const globalId = 60 + (i * 2);
            for (let c = 0; c < 4; c++) {
                this.scheduler.enqueue(protocol.buildNameRequest(globalId, c), 1);
            }
        }

        const outIndices = [];
        for (let i = 36; i <= 43; i++) outIndices.push(i);
        for (let i = 44; i <= 51; i++) outIndices.push(i);
        outIndices.push(52);
        for (const idx of outIndices) {
            for (let c = 0; c < 8; c++) {
                this.scheduler.enqueue(protocol.buildNameRequest(idx, c), 1);
            }
        }

        this.scheduler.onQ1Empty = () => {
            this._finishSync(null, '[OK] [SyncManager] Nomes sincronizados!');
        };
    }

    get isBusy() { return this.isSyncing; }
    get isReady() { return this.isFullySynced; }

    reset() {
        this.hasSyncedNamesThisSession = false;
    }
}

module.exports = SyncManager;
